from django.shortcuts import render, redirect
from .company_field import CompanyWorktimeFields, CompanyGenderFields, CompanyHaveCertFields, CompanySectionFields, CompanySizeFields
from .fields import citys, LearningDomainFields, JobTypeFields
from .models import CompanyCreateJobModel, CompanyProfile, UserProfile, EmployeeJobRequest, EmailVerificationCodeModel
import datetime
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

from pages.views import SendEmailVerification

# Create your views here.

def CompanySignup(request):
    if request.method == 'POST':
        complite_name = request.POST.get('complite_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        company_name = request.POST.get('company_name')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        company_profile = CompanyProfile.objects.create(complite_name=complite_name, company_name=company_name, phone=phone, creation_date=datetime.datetime.now())
        company_profile.save()

        user = User.objects.create(username=username, email=email)
        user.set_password(password)
        user.save()

        userprofile = UserProfile.objects.create(user=user, is_company=True, creation_date=datetime.datetime.now(), companyprofile=company_profile)
        userprofile.save()
        return redirect('SignIn')

        
    return render(request, 'pages/company_signup.html')

def SignIn(request):

    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        username = None
        user = User.objects.filter(email=email)
        
        if user.exists():
            username = user[0].username
        else:
            username = email

        user = authenticate(username=username, password=password)
        
        if user is not None:
            
            if user.is_superuser:
                login(request, user)
                return redirect('PanelHome')
            elif user.userprofile.is_company:
                login(request, user)
                return redirect('CompanyMain')
            elif user.userprofile.is_employee:
                # if user.userprofile.is_email_verificated:
                login(request, user)
                
                
                return redirect('index')
                
                # else:
                #     Verification_result = SendEmailVerification(user.userprofile)
                #     if Verification_result:
                #         messages.success(request, 'تم ارسال رسالة تاكيد عبر البريد الالكتروني الخاصة بك')
                #     else:
                #         messages.error(request, 'حدث خطاء اثناء ارسال رسالة تاكيد عبر البريد الالكتروني')
                    
        else:
            messages.error(request, 'خطاء في البريد الالكتروني او كلمة المرور')
        
    return render(request, 'accounts/signin.html')


def CompanyMain(request):
    user = request.user
    userprofile = user.userprofile
    jobs = CompanyCreateJobModel.objects.filter(userprofile=userprofile).order_by('-id')

    return render(request, 'accounts/company/main.html', {'jobs':jobs})

def Portal(request):
    user = request.user
    if user.is_superuser:
        return redirect('PanelHome')
    elif user.userprofile.is_company:
        return redirect('CompanyMain')
    elif user.userprofile.is_employee:
        return redirect('EmployeeMain')


def SignOut(request):
    logout(request)
    return redirect('SignIn')



def CompanyViewJob(request, id):
    
    job = CompanyCreateJobModel.objects.get(id=id)
    company = job.userprofile.companyprofile
    presenters = EmployeeJobRequest.objects.filter(company_job__id=id)
    
    return render(request, 'accounts/company/CompanyViewJob.html', {'company':company, 'job':job, 'presenters':presenters})



def EmployeeMain(request):
    user = request.user
    jobs = EmployeeJobRequest.objects.filter(company_job__post_state='3', employee=user).order_by('-id')

    return render(request, 'accounts/employee/main.html', {'jobs':jobs})


def CompanyCreateJob(request):
    if request.method == 'POST':
        company_history = request.POST.get('company_history')
        company_city = request.POST.get('company_city')
        company_size = request.POST.get('company_size')
        company_ico = request.FILES.get('company_ico')
        company_section = request.POST.get('company_section')
        company_have_cert = request.POST.get('company_have_cert')
        unwanted_disability = request.POST.get('unwanted_disability')
        wanted_disability = request.POST.get('wanted_disability')
        job_title = request.POST.get('job_title')
        job_desc = request.POST.get('job_desc')
        job_skils = request.POST.get('job_skils')
        work_hours = request.POST.get('work_hours')
        rest_days = request.POST.get('rest_days')
        medical_insurance = request.POST.get('medical_insurance')
        available_jobs = request.POST.get('available_jobs')
        job_requirements = request.POST.get('job_requirements')
        work_domain = request.POST.get('work_domain')
        cert_type = request.POST.get('cert_type')
        major = request.POST.get('major')
        basic_salary = request.POST.get('basic_salary')
        housing_allowance = request.POST.get('housing_allowance')
        other_allowances = request.POST.get('other_allowances')
        total_salary = request.POST.get('total_salary')
        gender = request.POST.get('gender')
        worktime = request.POST.get('worktime')
        job_type = request.POST.get('job_type')
        last_txt = request.POST.get('last_txt')
        
        user = request.user
        userprofile = user.userprofile
        create_job = CompanyCreateJobModel.objects.create(userprofile=userprofile)

        create_job.company_history = company_history
        create_job.company_city = company_city
        create_job.company_size = company_size
        create_job.company_ico = company_ico
        create_job.company_section = company_section
        create_job.company_have_cert = company_have_cert
        create_job.unwanted_disability = unwanted_disability
        create_job.wanted_disability = wanted_disability
        create_job.job_title = job_title
        create_job.job_desc = job_desc
        create_job.job_skils = job_skils
        create_job.work_hours = work_hours
        create_job.rest_days = rest_days
        create_job.medical_insurance = medical_insurance
        create_job.available_jobs = available_jobs
        create_job.job_requirements = job_requirements
        create_job.work_domain = work_domain
        create_job.cert_type = cert_type
        create_job.major = major
        create_job.basic_salary = basic_salary
        create_job.housing_allowance = housing_allowance
        create_job.other_allowances = other_allowances
        create_job.total_salary = total_salary
        create_job.gender = gender
        create_job.worktime = worktime
        create_job.last_txt = last_txt

        create_job.job_type = job_type
        create_job.post_state = '1'
        create_job.creation_date = datetime.datetime.now()
        create_job.save()
    

    return render(request, 'pages/reports/company.html', {'JobTypeFields':JobTypeFields, 'CompanyWorktimeFields':CompanyWorktimeFields, 'CompanyGenderFields':CompanyGenderFields, 'CompanyHaveCertFields':CompanyHaveCertFields, 'CompanySectionFields':CompanySectionFields, 'CompanySizeFields':CompanySizeFields, 'citys':citys, 'LearningDomainFields':LearningDomainFields})


def EmailVerificationCode(request, secret):
    obj = EmailVerificationCodeModel.objects.filter(secret=secret, is_active=True)

    if obj.exists():
        obj = obj[0]
        userprofile = UserProfile.objects.get(id=obj.userprofile.id)
        userprofile.is_email_verificated = True
        userprofile.save()
        obj.is_active = False
        obj.save()

        messages.success(request, 'تم تاكيد البريد بنجاح الرجاء تسجيل الدخول')
        return redirect('SignIn')
    else:
        messages.error(request, 'حدث خطاء')
        return redirect('index')
    